package E03Univercity.entities;

public enum Attendance {
    PERFECT, GOOD, AVERAGE, POOR, NEVER_ATTENDED
}
