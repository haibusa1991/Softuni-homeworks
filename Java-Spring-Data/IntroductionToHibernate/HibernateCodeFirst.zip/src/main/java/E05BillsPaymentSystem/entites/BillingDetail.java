package E05BillsPaymentSystem.entites;

public interface BillingDetail {
}
