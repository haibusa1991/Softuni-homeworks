package E05BillsPaymentSystem.entites;

public enum CreditCardType {
    VISA,MASTERCARD,AMERICAN_EXPRESS,DISCOVER,OTHER
}
