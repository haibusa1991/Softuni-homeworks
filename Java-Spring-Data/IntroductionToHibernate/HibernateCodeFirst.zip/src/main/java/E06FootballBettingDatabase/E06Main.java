package E06FootballBettingDatabase;

public class E06Main {

    //I will finish this at some point in the future - https://github.com/haibusa1991/Java-Spring-Data/tree/main/HibernateCodeFirst
}
