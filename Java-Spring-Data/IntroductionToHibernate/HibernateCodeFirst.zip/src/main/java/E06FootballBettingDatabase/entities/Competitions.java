package E06FootballBettingDatabase.entities;

public enum Competitions {
    LOCAL, NATIONAL, INTERNATIONAL
}
