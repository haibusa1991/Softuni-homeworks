package E06FootballBettingDatabase.entities;

public enum ResultPredictions {
    HOME_WINS, AWAY_WINS, DRAW
}
