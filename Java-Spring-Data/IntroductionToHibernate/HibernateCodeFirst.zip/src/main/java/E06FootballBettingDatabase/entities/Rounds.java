package E06FootballBettingDatabase.entities;

public enum Rounds {
    GROUP, LEAGUE, EIGHT_FINAL, QUARTER_FINAL, SEMI_FINAL, FINAL
}
