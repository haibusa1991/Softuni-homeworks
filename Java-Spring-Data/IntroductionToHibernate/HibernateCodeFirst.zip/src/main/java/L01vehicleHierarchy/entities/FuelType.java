package L01vehicleHierarchy.entities;

public enum FuelType {
    GASOLINE, DIESEL, ELECTRICITY, OTHER
}
