package L01vehicleHierarchy.entities;

public enum VehicleType {
    PASSENGER, CARGO, INDIVIDUAL
}
