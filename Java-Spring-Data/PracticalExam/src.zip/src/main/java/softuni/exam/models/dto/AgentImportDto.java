package softuni.exam.models.dto;

public class AgentImportDto {
    private String firstName;
    private String lastName;
    private String town;
    private String email;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getTown() {
        return town;
    }

    public String getEmail() {
        return email;
    }
}
