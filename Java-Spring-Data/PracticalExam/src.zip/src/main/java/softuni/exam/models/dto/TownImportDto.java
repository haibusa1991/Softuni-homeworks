package softuni.exam.models.dto;

public class TownImportDto {
    private String townName;
    private int population;

    public String getTownName() {
        return townName;
    }

    public int getPopulation() {
        return population;
    }
}
