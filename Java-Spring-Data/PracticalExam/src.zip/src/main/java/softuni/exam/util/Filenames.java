package softuni.exam.util;

public class Filenames {
    public static final String AGENTS_FILE = "src/main/resources/files/json/agents.json";
    public static final String TOWNS_FILE = "src/main/resources/files/json/towns.json";
    public static final String APARTMENTS_FILE = "src/main/resources/files/xml/apartments.xml";
    public static final String OFFERS_FILE = "src/main/resources/files/xml/offers.xml";
}
