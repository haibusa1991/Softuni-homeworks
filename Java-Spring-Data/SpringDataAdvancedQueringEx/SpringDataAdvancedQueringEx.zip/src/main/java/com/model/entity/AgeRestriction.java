package com.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
