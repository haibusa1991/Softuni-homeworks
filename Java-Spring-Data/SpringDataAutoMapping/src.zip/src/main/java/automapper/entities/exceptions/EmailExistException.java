package automapper.entities.exceptions;

public class EmailExistException extends Exception {

    public EmailExistException(String message) {
        super(message);
    }
}
