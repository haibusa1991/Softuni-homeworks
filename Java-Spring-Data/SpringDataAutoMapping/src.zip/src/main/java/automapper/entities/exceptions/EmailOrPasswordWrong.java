package automapper.entities.exceptions;

public class EmailOrPasswordWrong extends Exception {

    public EmailOrPasswordWrong(String message) {
        super(message);
    }
}
